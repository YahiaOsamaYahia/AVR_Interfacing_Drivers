/*
 * main.c
 *
 *  Created on: Jul 6, 2022
 *      Author: hazemahmed
 */
#include "BIT_OP.h"
#include"STD_TYPES.h"
#include"DIO_Interface.h"
#include"LCD_Interface.h"
#include"ADC_Interface.h"
#include<util/delay.h>
int main(){
	SET_Direction(PORT_C, PIN_0, OUTPUT);
	SET_Direction(PORT_C, PIN_1, OUTPUT);
	SET_Direction(PORT_C, PIN_2, OUTPUT);
	SET_Direction_4MSB(PORT_C, OUTPUT);
	SET_Direction(PORT_A, PIN_0, INPUT);
	LCD_Init();
	ADC_Init();
	u16 Digital;
	u16 Analog=0;
	u16 Analog_prev=0;
	while(1){
		ADC_Start(0);
		Digital=ADC_Result();
		Analog=Analog_Value(Digital);
		if(Analog!=Analog_prev){
	    LCD_SendCommands(0x01>>4);
	    LCD_SendCommands(0x01);
		LCD_SendNumbers(Analog);
		Analog_prev=Analog;
		}
		else{
			//Do Nothing
		}
		_delay_ms(500);
	}
	return 0;
}

