/*
 * main.c
 *
 *  Created on: Jul 19, 2022
 *      Author: hazemahmed
 */



#include"BIT_OP.h"
#include"STD_TYPES.h"
#include"TWI_Interface.h"
#include"DIO_Interface.h"
#include<util/delay.h>
int main(){
	SET_Direction(PORT_C, PIN_7, HIGH);
	TWI_SLAVE_INIT(0x20);
	u8 data;
	while(1){
		TWI_SLAVE_READ_ADDRESS_MATCH();
		data=TWI_SLAVE_READ();
		if(data==1){
			SET_Value(PORT_C, PIN_7, HIGH);
		}
		else if(data==0){
			SET_Value(PORT_C, PIN_7, LOW);
		}
	}
	return 0;
}

